#ifndef GAMEPLAY_H
#define GAMEPLAY_H
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

class gameplay {
	public:
		gameplay();		
		void displayAllCards();
		void findMelds();
		void drawCard();
		bool discardCard();
		int scorePlayerDeadwood();
		int scoreCPUDeadwood();
		void endScore();
	private:
		vector<int> stockPile;
		vector<int> discardPile;
		vector<int> playerHand;
		vector< vector<int> > playerMelds;
		vector<int> computerHand;
		vector< vector<int> > computerMelds;
		int turn;
};

gameplay::gameplay() {
	
	turn = 0;

	for(int i=0; i<52; i++){
		stockPile.push_back(i);
	}

	for(int i=0; i<52; i++){
		int j = (rand() + time(0)) % 52;
		int temp = stockPile[i];
		stockPile[i]=stockPile[j];
		stockPile[j]=temp;
	}

	for(int i=0; i<10; i++){
		playerHand.push_back(stockPile[0]);
		stockPile.erase(stockPile.begin());
	}

	for(int i=0; i<10; i++){
		computerHand.push_back(stockPile[0]);
		stockPile.erase(stockPile.begin());
	}
	
	discardPile.push_back(stockPile[0]);
	stockPile.erase(stockPile.begin());
}

void gameplay::displayAllCards() {

	sort(playerHand.begin(),playerHand.end());
	sort(computerHand.begin(),computerHand.end());

	findMelds();

	string deck[13][4] = {
		
		{ " 🂡 " , " 🂱 " , " 🃁 " , " 🃑 " },

		{ " 🂢 " , " 🂲 " , " 🃂 " , " 🃒 " },

		{ " 🂣 " , " 🂳 " , " 🃃 " , " 🃓 " },

		{ " 🂤 " , " 🂴 " , " 🃄 " , " 🃔 " },

		{ " 🂥 " , " 🂵 " , " 🃅 " , " 🃕 " },

		{ " 🂦 " , " 🂶 " , " 🃆 " , " 🃖 " },

		{ " 🂧 " , " 🂷 " , " 🃇 " , " 🃗 " },

		{ " 🂨 " , " 🂸 " , " 🃈 " , " 🃘 " },

		{ " 🂩 " , " 🂹 " , " 🃉 " , " 🃙 " },

		{ " 🂪 " , " 🂺 " , " 🃊 " , " 🃚 " },

		{ " 🂫 " , " 🂻 " , " 🃋 " , " 🃛 " },

		{ " 🂭 " , " 🂽 " , " 🃍 " , " 🃝 " },

		{ " 🂮 " , " 🂾 " , " 🃎 " , " 🃞 " }

	};
	
	cout << endl << "Your Hand: ";
	for(int i=0; i<playerHand.size(); i++){
		cout << deck[playerHand[i]/4][playerHand[i]%4] << "<-" << i;
	}
	cout << endl << endl;
	if(playerMelds.size()>0){
		cout << endl << "Your Possible Melds: ";
		for(int i=0; i<playerMelds.size(); i++){
			cout << "  ";
			for(int j=0; j<playerMelds[i].size(); j++){
				cout << deck[playerHand[playerMelds[i][j]]/4][playerHand[playerMelds[i][j]]%4];
			}
		}
		cout << endl << endl;
	}
	/*
	cout << endl << "Computer Hand: ";
	for(int i=0; i<computerHand.size(); i++){
		cout << deck[computerHand[i]/4][computerHand[i]%4] << "<-" << i;
	}
	cout << endl << endl;
	if(computerMelds.size()>0){
		cout << endl << "Computer Possible Melds: ";
		for(int i=0; i<computerMelds.size(); i++){
			cout << "  ";
			for(int j=0; j<computerMelds[i].size(); j++){
				cout << deck[computerHand[computerMelds[i][j]]/4][computerHand[computerMelds[i][j]]%4];
			}
		}
		cout << endl << endl;
	}
	*/
	cout << endl << "Discard Pile: ";
	cout << deck[discardPile.back()/4][discardPile.back()%4];
	cout << endl << endl;
	cout << endl << "Stock Pile: " << stockPile.size() << " cards";
	/*
	for(int i=0; i<stockPile.size(); i++){
		cout << deck[stockPile[i]/4][stockPile[i]%4];
	}*/
	cout << endl << endl;
	

}

void gameplay::findMelds() {
//find and optimize the melds (sets and runs) in player/computer's hand
	int playerMeldsCount=0;
	playerMelds.resize(0);
	for(int i=0; i<playerHand.size(); i++){	
		for(int j=i+1; j<playerHand.size(); j++){
			if(playerHand[j]/4==playerHand[i]/4){
				for(int k=j+1; k<playerHand.size(); k++){
					if(playerHand[k]/4==playerHand[j]/4){
						playerMelds.resize(playerMeldsCount+1);
						playerMelds[playerMeldsCount].push_back(i);
						playerMelds[playerMeldsCount].push_back(j);
						playerMelds[playerMeldsCount].push_back(k);
						for(int l=k+1; l<playerHand.size(); l++){
							if(playerHand[l]/4==playerHand[k]/4){
								playerMelds[playerMeldsCount].push_back(l);
							}
						}
						playerMeldsCount++;
					}
				}
			}
		}
	}
	for(int i=0; i<playerHand.size(); i++){	
		for(int j=i+1; j<playerHand.size(); j++){
			if(playerHand[j]%4==playerHand[i]%4){
				for(int k=j+1; k<playerHand.size(); k++){
					if(playerHand[k]%4==playerHand[j]%4){
						//playerHand[i], playerHand[j], and playerHand[k] compare
						for(int l=k+1; l<playerHand.size(); l++){
							if(playerHand[l]%4==playerHand[k]%4){
								//playerHand[i], playerHand[j], playerHand[k], and playerHand[l] compare
								for(int m=l+1; m<playerHand.size(); m++){
									if(playerHand[m]%4==playerHand[l]%4){
									//playerHand[i], playerHand[j], playerHand[k], playerHand[l], and playerHand[m] compare (no more for loops needed since a run of six or more can be broken up into runs of three and four)
									}
								}
							}
						}
					}
				}
			}
		}
	}
	int computerMeldsCount=0;
	computerMelds.resize(0);
	for(int i=0; i<computerHand.size(); i++){
		for(int j=i+1; j<computerHand.size(); j++){
			if(computerHand[j]/4==computerHand[i]/4){
				for(int k=j+1; k<computerHand.size(); k++){
					if(computerHand[k]/4==computerHand[j]/4){
						computerMelds.resize(computerMeldsCount+1);
						computerMelds[computerMeldsCount].push_back(i);
						computerMelds[computerMeldsCount].push_back(j);
						computerMelds[computerMeldsCount].push_back(k);
						for(int l=k+1; l<computerHand.size(); l++){
							if(computerHand[l]/4==computerHand[k]/4){
								computerMelds[computerMeldsCount].push_back(l);
							}
						}
						computerMeldsCount++;
					}
				}
			}
		}
	}
}

void gameplay::drawCard() {
	turn++;
	cout << "\n\nTurn #" << turn << endl;
	displayAllCards();
	int drawSelect=0;
	if(turn%2==1){
		cout << "Draw a card. Enter 1 for Stock Pile or 2 for Discard Pile: ";
		cin >> drawSelect;
		if(drawSelect==1){
			playerHand.push_back(stockPile.back());
			stockPile.pop_back();
		}
		else if(drawSelect==2){
			playerHand.push_back(discardPile.back());
			discardPile.pop_back();
		}
	}
	else if(turn%2==0){
		int drawRandom = (rand() + time(0)) % 2;
		if(drawRandom==0){
			cout << "Computer drew a card from the Stock Pile." << endl;
			computerHand.push_back(stockPile.back());
			stockPile.pop_back();
		}
		else if(drawRandom==1){
			cout << "Computer drew a card from the Discard Pile." << endl;
			computerHand.push_back(discardPile.back());
			discardPile.pop_back();
		}
	}
	displayAllCards();
}


bool gameplay::discardCard() {
	string keepPlaying;
	if(turn%2==1){
		int cardChoice = 0;
		cout << "Enter 'n' or 'N' to knock and end the game, or enter any other key to continue: ";
		cin >> keepPlaying;
		cout << endl << "Enter a number between 0-9 to select a card from your hand to discard (10 was just drawn so it cannot be discarded this turn): ";
		cin >> cardChoice;
		discardPile.push_back(playerHand[cardChoice]);
		playerHand.erase(playerHand.begin()+cardChoice);
	}	
	else if(turn%2==0){
		int discardRandom = (rand() + time(0)) % 11;
		for(int i=0; i<computerMelds.size();i++){			
			for(int j=0;j<computerMelds[i].size();j++){
				if(discardRandom==computerMelds[i][j]){
					discardRandom = (discardRandom + 1) % 11;
					j=0;
					i=0;
				}
			}
		}
		if(stockPile.size()<4 || scoreCPUDeadwood()<=10 ){
			cout << endl << "Computer knocked." << endl;
			keepPlaying="n";
		}
		cout << endl << "Computer discarded a card." << endl;
		discardPile.push_back(computerHand[discardRandom]);
		computerHand.erase(computerHand.begin()+discardRandom);
	}
	if(keepPlaying == "n" || keepPlaying == "N") {
			displayAllCards();
			return 0;
	}
	return 1;
}

int gameplay::scorePlayerDeadwood() {
	int sum = 0;	
	for(int i=0; i<playerHand.size(); i++) {
		for(int j=0; j<playerMelds.size();j++){			
			for(int k=0;k<playerMelds[j].size();k++){
				if(i==playerMelds[j][k]){
					i++;
					k=0;
					j=0;
				}
			}
		}
		if(i<playerHand.size()){
			if(playerHand[i]/4 < 10) {
				sum += playerHand[i]/4+1;
			}
			else {
				sum += 10;
			}
		}
	}
	return sum;
}

int gameplay::scoreCPUDeadwood() {
	int sum = 0;	
	for(int i=0; i<computerHand.size(); i++) {
		for(int j=0; j<computerMelds.size();j++){			
			for(int k=0;k<computerMelds[j].size();k++){
				if(i==computerMelds[j][k]){
					i++;
					k=0;
					j=0;
				}
			}
		}

		if(i<computerHand.size()){
			if(computerHand[i]/4 < 10) {
				sum += computerHand[i]/4+1;
			}
			else {
				sum += 10;
			}
		}
	}
	return sum;
}

void gameplay::endScore(){

	cout << "Player deadwood: " << scorePlayerDeadwood() << endl;
	cout << "CPU deadwood: " << scoreCPUDeadwood() << endl;
	if (scorePlayerDeadwood() < scoreCPUDeadwood()) {
		cout << "The player wins the round!\n";
	}
	else if (scorePlayerDeadwood() > scoreCPUDeadwood()) {
		cout << "The cpu wins the round!\n";
	}
	else {
		cout << "The round ends in a tie!\n";
	}

}

#endif
