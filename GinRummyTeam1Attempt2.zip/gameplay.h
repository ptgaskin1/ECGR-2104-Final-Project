#ifndef GAMEPLAY_H
#define GAMEPLAY_H
#include <iostream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include <algorithm>

using namespace std;

		string deck[13][4] = {
			
			{ " 🂡 " , " 🂱 " , " 🃁 " , " 🃑 " },
			
			{ " 🂢 " , " 🂲 " , " 🃂 " , " 🃒 " },
			
			{ " 🂣 " , " 🂳 " , " 🃃 " , " 🃓 " },
			
			{ " 🂤 " , " 🂴 " , " 🃄 " , " 🃔 " },
			
			{ " 🂥 " , " 🂵 " , " 🃅 " , " 🃕 " },
			
			{ " 🂦 " , " 🂶 " , " 🃆 " , " 🃖 " },
			
			{ " 🂧 " , " 🂷 " , " 🃇 " , " 🃗 " },
			
			{ " 🂨 " , " 🂸 " , " 🃈 " , " 🃘 " },
			
			{ " 🂩 " , " 🂹 " , " 🃉 " , " 🃙 " },
			
			{ " 🂪 " , " 🂺 " , " 🃊 " , " 🃚 " },
			
			{ " 🂫 " , " 🂻 " , " 🃋 " , " 🃛 " },
			
			{ " 🂭 " , " 🂽 " , " 🃍 " , " 🃝 " },
			
			{ " 🂮 " , " 🂾 " , " 🃎 " , " 🃞 " }
			
		};

class gameplay {
	public:
		gameplay();
		void setup();		
		void displayAllCards();
		void findMelds();
		int checkPlayerMelds(int);
		int checkComputerMelds(int);
		void drawCard();
		bool discardCard();
		int scorePlayerDeadwood();
		int scoreCPUDeadwood();
		void endScore();
	private:
		vector<int> stockPile;
		vector<int> discardPile;
		vector<int> playerHand;
		vector< vector<int> > playerMelds;
		vector<int> computerHand;
		vector< vector<int> > computerMelds;
		int turn;

};

gameplay::gameplay() {setup();}

void gameplay::setup() {
	
	turn = 0;
	stockPile.resize(0);
	discardPile.resize(0);
	playerHand.resize(0);
	computerHand.resize(0);

	for(int i=0; i<52; i++){
		stockPile.push_back(i);
	}

	for(int i=0; i<52; i++){
		int j = (rand() + time(0)) % 52;
		int temp = stockPile[i];
		stockPile[i]=stockPile[j];
		stockPile[j]=temp;
	}

	for(int i=0; i<10; i++){
		playerHand.push_back(stockPile[0]);
		stockPile.erase(stockPile.begin());
	}

	for(int i=0; i<10; i++){
		computerHand.push_back(stockPile[0]);
		stockPile.erase(stockPile.begin());
	}
	
	discardPile.push_back(stockPile[0]);
	stockPile.erase(stockPile.begin());

}

void gameplay::displayAllCards() {

	sort(playerHand.begin(),playerHand.end());
	sort(computerHand.begin(),computerHand.end());

	findMelds();
	
	cout << "\n\nYour Hand: ";
	for(int i=0; i<playerHand.size(); i++){
		cout << deck[playerHand[i]/4][playerHand[i]%4] << "<-" << i;
	}
	cout << endl;
	if(playerMelds.size()>0){
		cout << "\nYour Melds: ";
		for(int i=0; i<playerMelds.size(); i++){
			cout << "  ";
			for(int j=0; j<playerMelds[i].size(); j++){
				cout << deck[playerHand[playerMelds[i][j]]/4][playerHand[playerMelds[i][j]]%4];
			}
		}
		cout << endl;
	}
	cout << endl << endl << "Discard Pile: ";
	if(discardPile.size()>0){
		cout << deck[discardPile.back()/4][discardPile.back()%4];
	}
	else{
		cout << "      (EMPTY)";
	}
	cout << endl;
	cout << endl << "Stock Pile:    🂠    (" << stockPile.size() << " cards left)";
	cout << endl << endl << endl;
	

}

void gameplay::findMelds() {
//find and optimize the melds (sets and runs) in player/computer's hand
	int playerMeldsCount=0;
	playerMelds.resize(0);
	for(int i=0; i<playerHand.size(); i++){
		if(i+1<playerHand.size() && playerHand[i+1]/4==playerHand[i]/4){
			if(i+2<playerHand.size() && playerHand[i+2]/4==playerHand[i]/4){
				playerMelds.resize(playerMeldsCount+1);
				if(i+3<playerHand.size() && playerHand[i+3]/4==playerHand[i]/4){
					playerMelds[playerMeldsCount].push_back(i);
					playerMelds[playerMeldsCount].push_back(i+1);
					playerMelds[playerMeldsCount].push_back(i+2);
					playerMelds[playerMeldsCount].push_back(i+3);
					i+=3;
				}
				else{
					playerMelds[playerMeldsCount].push_back(i);
					playerMelds[playerMeldsCount].push_back(i+1);
					playerMelds[playerMeldsCount].push_back(i+2);
					i+=2;
				}
				playerMeldsCount++;
			}
			else{i++;}
		}
	}
	for(int i=0; i<playerHand.size(); i++){
		i=checkPlayerMelds(i);
		for(int j=i+1; (j<=i+4 && j<playerHand.size()); j++){
			j=checkPlayerMelds(j);
			if(playerHand[j]==playerHand[i]+4){
				for(int k=j+1; (k<=j+4 && k<playerHand.size()); k++){
					k=checkPlayerMelds(k);
					if(playerHand[k]==playerHand[j]+4){
						playerMelds.resize(playerMeldsCount+1);
						playerMelds[playerMeldsCount].push_back(i);
						playerMelds[playerMeldsCount].push_back(j);
						playerMelds[playerMeldsCount].push_back(k);
						for(int l=k+1; (l<=k+4 && l<playerHand.size()); l++){
							l=checkPlayerMelds(l);
							if(playerHand[l]==playerHand[k]+4){
								playerMelds[playerMeldsCount].push_back(l);
								for(int m=l+1; (m<=l+4 && m<playerHand.size()); m++){
									m=checkPlayerMelds(m);
									if(playerHand[m]==playerHand[l]+4){
										playerMelds[playerMeldsCount].push_back(m);
										for(int n=m+1; (n<=m+4 && n<playerHand.size()); n++){
											n=checkPlayerMelds(n);
											if(playerHand[n]==playerHand[m]+4){
												playerMelds[playerMeldsCount].push_back(n);
												for(int o=n+1; (o<=n+4 && o<playerHand.size()); o++){
													o=checkPlayerMelds(o);
													if(playerHand[o]==playerHand[n]+4){
														playerMelds[playerMeldsCount].push_back(o);
														for(int p=o+1; (p<=o+4 && p<playerHand.size()); p++){
															p=checkPlayerMelds(p);
															if(playerHand[p]==playerHand[o]+4){
																playerMelds[playerMeldsCount].push_back(p);
																for(int q=p+1; (q<=p+4 && q<playerHand.size()); q++){
																	q=checkPlayerMelds(q);
																	if(playerHand[q]==playerHand[p]+4){
																		playerMelds[playerMeldsCount].push_back(q);
																		for(int r=q+1; (r<=q+4 && r<playerHand.size()); r++){
																			r=checkPlayerMelds(r);
																			if(playerHand[r]==playerHand[q]+4){
																				playerMelds[playerMeldsCount].push_back(r);
																				for(int s=r+1; (s<=r+4 && r<playerHand.size()); s++){
																					s=checkPlayerMelds(s);
																					if(playerHand[s]==playerHand[r]+4){
																						playerMelds[playerMeldsCount].push_back(s);
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						playerMeldsCount++;
					}
				}
			}
		}
	}
	int computerMeldsCount=0;
	computerMelds.resize(0);
	for(int i=0; i<computerHand.size(); i++){
		if(i+1<computerHand.size() && computerHand[i+1]/4==computerHand[i]/4){
			if(i+2<computerHand.size() && computerHand[i+2]/4==computerHand[i]/4){
				computerMelds.resize(computerMeldsCount+1);
				if(i+3<computerHand.size() && computerHand[i+3]/4==computerHand[i]/4){
					computerMelds[computerMeldsCount].push_back(i);
					computerMelds[computerMeldsCount].push_back(i+1);
					computerMelds[computerMeldsCount].push_back(i+2);
					computerMelds[computerMeldsCount].push_back(i+3);
					i+=3;
				}
				else{
					computerMelds[computerMeldsCount].push_back(i);
					computerMelds[computerMeldsCount].push_back(i+1);
					computerMelds[computerMeldsCount].push_back(i+2);
					i+=2;
				}
				computerMeldsCount++;
			}
			else{i++;}
		}
	}
	for(int i=0; i<computerHand.size(); i++){
		i=checkComputerMelds(i);
		for(int j=i+1; (j<=i+4 && j<computerHand.size()); j++){
			j=checkComputerMelds(j);
			if(computerHand[j]==computerHand[i]+4){
				for(int k=j+1; (k<=j+4 && k<computerHand.size()); k++){
					k=checkComputerMelds(k);
					if(computerHand[k]==computerHand[j]+4){
						computerMelds.resize(computerMeldsCount+1);
						computerMelds[computerMeldsCount].push_back(i);
						computerMelds[computerMeldsCount].push_back(j);
						computerMelds[computerMeldsCount].push_back(k);
						for(int l=k+1; (l<=k+4 && l<computerHand.size()); l++){
							l=checkComputerMelds(l);
							if(computerHand[l]==computerHand[k]+4){
								computerMelds[computerMeldsCount].push_back(l);
								for(int m=l+1; (m<=l+4 && m<computerHand.size()); m++){
									m=checkComputerMelds(m);
									if(computerHand[m]==computerHand[l]+4){
										computerMelds[computerMeldsCount].push_back(m);
										for(int n=m+1; (n<=m+4 && n<computerHand.size()); n++){
											n=checkComputerMelds(n);
											if(computerHand[n]==computerHand[m]+4){
												computerMelds[computerMeldsCount].push_back(n);
												for(int o=n+1; (o<=n+4 && o<computerHand.size()); o++){
													o=checkComputerMelds(o);
													if(computerHand[o]==computerHand[n]+4){
														computerMelds[computerMeldsCount].push_back(o);
														for(int p=o+1; (p<=o+4 && p<computerHand.size()); p++){
															p=checkComputerMelds(p);
															if(computerHand[p]==computerHand[o]+4){
																computerMelds[computerMeldsCount].push_back(p);
																for(int q=p+1; (q<=p+4 && q<computerHand.size()); q++){
																	q=checkComputerMelds(q);
																	if(computerHand[q]==computerHand[p]+4){
																		computerMelds[computerMeldsCount].push_back(q);
																		for(int r=q+1; (r<=q+4 && r<computerHand.size()); r++){
																			r=checkComputerMelds(r);
																			if(computerHand[r]==computerHand[q]+4){
																				computerMelds[computerMeldsCount].push_back(r);
																				for(int s=r+1; (s<=r+4 && r<computerHand.size()); s++){
																					s=checkComputerMelds(s);
																					if(computerHand[s]==computerHand[r]+4){
																						computerMelds[computerMeldsCount].push_back(s);
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
						computerMeldsCount++;
					}
				}
			}
		}
	}
}

int gameplay::checkPlayerMelds(int a) {
	for(int b=0; b<playerMelds.size();b++){			
		for(int c=0;c<playerMelds[b].size();c++){
			if(a==playerMelds[b][c]){
				a++;
				b=0;
				c=0;
			}
		}
	}
	return a;
}

int gameplay::checkComputerMelds(int a) {
	for(int b=0; b<computerMelds.size();b++){			
		for(int c=0;c<computerMelds[b].size();c++){
			if(a==computerMelds[b][c]){
				a++;
				b=0;
				c=0;
			}
		}
	}
	return a;
}

void gameplay::drawCard() {
	turn++;
	int drawSelect=0;
	if(turn%2==1){
		cout << "\n\n\nYour Turn" << endl;
		displayAllCards();
		while(drawSelect!=1 && drawSelect!=2){
			cout << "Draw a card. Enter 1 for Stock Pile or 2 for Discard Pile: ";
			cin >> drawSelect;
		}
		if(drawSelect==1){
			playerHand.push_back(stockPile.back());
			cout << "\nYou drew" << deck[stockPile.back()/4][stockPile.back()%4] << " from the Stock Pile." << endl;
			stockPile.pop_back();
		}
		else if(drawSelect==2){
			playerHand.push_back(discardPile.back());
			cout << "\nYou drew" << deck[discardPile.back()/4][discardPile.back()%4] << " from the Discard Pile." << endl;
			discardPile.pop_back();
		}
	}
	else if(turn%2==0){
		cout << "\n\n\nComputer's Turn" << endl;
		displayAllCards();
		int drawRandom = (rand() + time(0)) % 2;
		if(drawRandom==0){
			computerHand.push_back(stockPile.back());
			cout << "Computer drew a card from the Stock Pile." << endl;
			stockPile.pop_back();
		}
		else if(drawRandom==1){
			computerHand.push_back(discardPile.back());
			cout << "Computer drew" << deck[discardPile.back()/4][discardPile.back()%4] << " from the Discard Pile." << endl;
			discardPile.pop_back();
		}
	}
	displayAllCards();
}


bool gameplay::discardCard() {
	string keepPlaying;
	if(turn%2==1){
		int cardChoice = 0;
		cout << "Enter 'n' or 'N' to knock and end the game, or enter any other key to continue: ";
		cin >> keepPlaying;
		do{
			cout << endl << "Enter a number between 0-10 to select a card from your hand to discard: ";
			cin >> cardChoice;
		}while(cardChoice<0 || cardChoice>10);
		discardPile.push_back(playerHand[cardChoice]);
		cout << "\nYou discarded" <<  deck[discardPile.back()/4][discardPile.back()%4] << " this turn." << endl;
		playerHand.erase(playerHand.begin()+cardChoice);
	}	
	else if(turn%2==0){
		int discardRandom = (rand() + time(0)) % 11;
		for(int i=0; i<computerMelds.size();i++){			
			for(int j=0;j<computerMelds[i].size();j++){
				if(discardRandom==computerMelds[i][j]){
					discardRandom = (discardRandom + 1) % 11;
					j=0;
					i=0;
				}
			}
		}
		if(stockPile.size()<=4 || scoreCPUDeadwood()<=10 ){
			cout << endl << "Computer knocked." << endl;
			keepPlaying="n";
		}
		discardPile.push_back(computerHand[discardRandom]);
		cout << "Computer discarded" <<  deck[discardPile.back()/4][discardPile.back()%4] << " this turn." << endl;
		computerHand.erase(computerHand.begin()+discardRandom);
	}
	if(keepPlaying == "n" || keepPlaying == "N") {
			displayAllCards();
			return 0;
	}
	return 1;
}

int gameplay::scorePlayerDeadwood() {
	int sum = 0;	
	for(int i=0; i<playerHand.size(); i++) {
		for(int j=0; j<playerMelds.size();j++){			
			for(int k=0;k<playerMelds[j].size();k++){
				if(i==playerMelds[j][k]){
					i++;
					k=0;
					j=0;
				}
			}
		}
		if(i<playerHand.size()){
			if(playerHand[i]/4 < 10) {
				sum += playerHand[i]/4+1;
			}
			else {
				sum += 10;
			}
		}
	}
	return sum;
}

int gameplay::scoreCPUDeadwood() {
	int sum = 0;	
	for(int i=0; i<computerHand.size(); i++) {
		for(int j=0; j<computerMelds.size();j++){			
			for(int k=0;k<computerMelds[j].size();k++){
				if(i==computerMelds[j][k]){
					i++;
					k=0;
					j=0;
				}
			}
		}

		if(i<computerHand.size()){
			if(computerHand[i]/4 < 10) {
				sum += computerHand[i]/4+1;
			}
			else {
				sum += 10;
			}
		}
	}
	return sum;
}

void gameplay::endScore(){

	cout << "Player deadwood: " << scorePlayerDeadwood() << endl;
	cout << "CPU deadwood: " << scoreCPUDeadwood() << endl;
	if (scorePlayerDeadwood() < scoreCPUDeadwood()) {
		cout << "The player wins the round!\n";
	}
	else if (scorePlayerDeadwood() > scoreCPUDeadwood()) {
		cout << "The cpu wins the round!\n";
	}
	else {
		cout << "The round ends in a tie!\n";
	}
	setup();
}

#endif
