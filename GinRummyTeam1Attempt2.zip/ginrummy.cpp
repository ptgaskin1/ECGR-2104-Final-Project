#include "gameplay.h"
int main() {
	gameplay game;
	do{game.drawCard();}while(game.discardCard());
	game.endScore();
}
